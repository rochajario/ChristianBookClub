﻿using ChristianBookClub.Data.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ChristianBookClub.Data
{
    public class ApplicationDbContext : IdentityDbContext<User, IdentityRole<long>, long>
    {
        #region Entities
        public DbSet<User> AspNetUsers { get; set; }
        public DbSet<Seminar> Seminars { get; set; }
        public DbSet<SeminarSchedule> SeminarSchedules { get; set; }
        public DbSet<SeminarRegister> SeminarRegisters { get; set; }
        public DbSet<SeminarAttendance> SeminarAttendances { get; set; }
        #endregion

        #region Views
        public DbSet<Subscription> Subscriptions { get; set; }
        public DbSet<UpcomingSeminar> UpcomingSeminars { get; set; }
        #endregion

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder
                .Entity<Subscription>()
                .ToView(nameof(Subscriptions))
                .HasKey(k => k.SeminarId);

            builder
                .Entity<UpcomingSeminar>()
                .ToView(nameof(UpcomingSeminars))
                .HasKey(k => k.SeminarId);
        }
    }
}


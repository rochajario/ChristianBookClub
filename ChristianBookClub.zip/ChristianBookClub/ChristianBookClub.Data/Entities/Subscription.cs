﻿namespace ChristianBookClub.Data.Entities
{
    public class Subscription
    {
        public long SeminarId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Details { get; set; } = string.Empty;
        public long? UserId { get; set; }
        public DateTime NextMeeting { get; set; }
    }
}

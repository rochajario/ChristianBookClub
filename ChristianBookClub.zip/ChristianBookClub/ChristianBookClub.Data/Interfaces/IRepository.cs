﻿using ChristianBookClub.Data.Entities;

namespace ChristianBookClub.Data.Interfaces
{
    public interface IRepository<T> where T : BaseEntity<T>
    {
        void Create(T item);
        void Delete(long id);
        IQueryable<T> GetAll();
        T GetById(long id);
        void Update(long id, T item);
    }
}
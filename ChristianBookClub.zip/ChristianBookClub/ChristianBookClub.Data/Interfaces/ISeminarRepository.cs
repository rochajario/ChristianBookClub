﻿using ChristianBookClub.Data.Entities;

namespace ChristianBookClub.Data.Interfaces
{
    public interface ISeminarRepository : IRepository<Seminar>
    {
        void AddSubscription(long userId, long seminarId);
        IEnumerable<Subscription> GetSubscriptions();
        IEnumerable<UpcomingSeminar> GetUpcomingSeminars();
        void RemoveSubscription(long userId, long seminarId);
    }
}

﻿using ChristianBookClub.Data.Entities;
using ChristianBookClub.Domain.Models.Forms;

namespace ChristianBookClub.Domain.Interfaces
{
    public interface ISeminarService
    {
        void AddSubscription(long userId, long seminarId);
        public void Create(SeminarForm form);
        IEnumerable<Seminar> GetSeminars(Func<Seminar, bool> function);
        IEnumerable<Subscription> GetSubscsriptions();
        IEnumerable<UpcomingSeminar> GetUpcomingSeminars();
        void RemoveSubscription(long userId, long seminarId);
    }
}

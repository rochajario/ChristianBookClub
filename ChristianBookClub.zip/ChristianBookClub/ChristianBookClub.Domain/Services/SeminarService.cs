﻿using ChristianBookClub.Data.Entities;
using ChristianBookClub.Data.Interfaces;
using ChristianBookClub.Domain.Interfaces;
using ChristianBookClub.Domain.Models.Forms;

namespace ChristianBookClub.Domain.Services
{
    public class SeminarService(ISeminarRepository seminarRepository) : ISeminarService
    {
        private readonly ISeminarRepository _seminarRepository = seminarRepository;

        public void Create(SeminarForm form)
        {
            var item = new Seminar
            {
                Name = form.Name,
                Description = form.Description,
                CoverImage = form.CoverImage
            };

            var schedules = new List<SeminarSchedule>();
            foreach (var schedule in form.Schedules)
            {
                schedules.Add(new SeminarSchedule
                {
                    MeetingDate = schedule.MeetingDate,
                    MeetingDetails = schedule.MeetingDetails
                });
            }

            item.SeminarSchedules = schedules;
            _seminarRepository.Create(item);
        }

        public IEnumerable<Seminar> GetSeminars(Func<Seminar, bool> function)
        {
            return _seminarRepository.GetAll().Where(function);
        }

        public IEnumerable<Subscription> GetSubscsriptions()
        {
            return _seminarRepository.GetSubscriptions();
        }

        public IEnumerable<UpcomingSeminar> GetUpcomingSeminars()
        {
            return _seminarRepository.GetUpcomingSeminars();
        }

        public void AddSubscription(long userId, long seminarId)
        {
            _seminarRepository.AddSubscription(userId, seminarId);
        }

        public void RemoveSubscription(long userId, long seminarId)
        {
            _seminarRepository.RemoveSubscription(userId, seminarId);
        }
    }
}

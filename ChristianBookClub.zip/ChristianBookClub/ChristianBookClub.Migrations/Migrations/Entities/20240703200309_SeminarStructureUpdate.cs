﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ChristianBookClub.Migrations.Migrations.Entities
{
    /// <inheritdoc />
    public partial class SeminarStructureUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "MeetingDetails",
                table: "SeminarSchedules",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CoverImage",
                table: "Seminars",
                type: "TEXT",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MeetingDetails",
                table: "SeminarSchedules");

            migrationBuilder.DropColumn(
                name: "CoverImage",
                table: "Seminars");
        }
    }
}

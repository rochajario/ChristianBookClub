﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ChristianBookClub.Migrations.Migrations.Views
{
    public partial class Subcsriptions : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE VIEW Subscriptions AS SELECT
	                s.Id as 'SeminarId',
	                s.Name,
	                sr.UserId,
	                MIN(ss.MeetingDate) as 'NextMeeting',
	                ss.MeetingDetails as 'Details'
                FROM
	                Seminars s
                INNER JOIN SeminarSchedules ss ON
	                ss.SeminarId = s.Id
                LEFT JOIN SeminarRegisters sr ON
	                s.Id = sr.SeminarId
                WHERE 
	                DATE('now') <= ss.MeetingDate 
                GROUP BY 1,3
                ORDER BY 4;
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP VIEW Subscriptions;");
        }
    }
}

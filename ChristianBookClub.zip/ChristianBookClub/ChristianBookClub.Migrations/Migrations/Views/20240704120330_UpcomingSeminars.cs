﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ChristianBookClub.Migrations.Migrations.Views
{
    /// <inheritdoc />
    public partial class UpcomingSeminars : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE VIEW UpcomingSeminars AS SELECT
	                s.Id as 'SeminarId',
	                s.Name,
	                s.Description,
	                s.CoverImage,
	                MIN(ss.MeetingDate) as 'NextMeeting',
	                ss.MeetingDetails as 'Details'
                FROM
	                Seminars s
                INNER JOIN SeminarSchedules ss ON
	                ss.SeminarId = s.Id
                WHERE 
	                DATE('now') <= ss.MeetingDate 
                GROUP BY 1
                ORDER BY 5;
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP VIEW UpcomingSeminars;");
        }
    }
}

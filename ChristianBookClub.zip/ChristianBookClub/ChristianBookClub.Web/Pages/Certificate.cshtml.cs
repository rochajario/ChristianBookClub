using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChristianBookClub.Web.Pages
{
    public class CertificateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

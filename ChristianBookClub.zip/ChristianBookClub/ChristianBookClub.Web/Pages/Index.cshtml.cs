using ChristianBookClub.Data.Entities;
using ChristianBookClub.Domain.Interfaces;
using ChristianBookClub.Domain.Services;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookClub.Pages
{
    public class IndexModel(ILogger<IndexModel> logger, ISeminarService seminarService) : PageModel
    {
        private readonly ILogger<IndexModel> _logger = logger;
        private readonly ISeminarService _seminarService = seminarService;

        public IEnumerable<Subscription> Subscriptions { get; private set; } = Enumerable.Empty<Subscription>();
        public IEnumerable<UpcomingSeminar> UpcomingSeminars { get; private set; } = Enumerable.Empty<UpcomingSeminar>();

        public void OnGet()
        {
            UpcomingSeminars = _seminarService.GetUpcomingSeminars();
            Subscriptions = _seminarService.GetSubscsriptions();
        }
    }
}

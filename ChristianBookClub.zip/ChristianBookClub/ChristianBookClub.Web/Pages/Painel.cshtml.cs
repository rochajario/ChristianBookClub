﻿using ChristianBookClub.Data.Entities;
using ChristianBookClub.Domain.Interfaces;
using ChristianBookClub.Web.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookClub.Pages
{
    public class PainelModel(ISeminarService seminarService, UserManager<User> userManager) : PageModel
    {
        private readonly ISeminarService _seminarService = seminarService;
        private readonly UserManager<User> _userManager = userManager;

        public IList<SubscriptionViewModel> SubscriptionsViewModels { get; private set; } = new List<SubscriptionViewModel>();

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is not null)
            {
                LoadSubscriptions(Convert.ToInt64(user.Id));
                return Page();
            }

            return new RedirectToPageResult("./Index");
        }

        public IActionResult OnGetSubscribe(long seminarId)
        {
            var userId = _userManager.GetUserId(User);
            _seminarService.AddSubscription(Convert.ToInt64(userId), seminarId);

            return OnGetAsync()
                .ConfigureAwait(true)
                .GetAwaiter()
                .GetResult();
        }

        public IActionResult OnGetUnsubscribe(long seminarId)
        {
            var userId = _userManager.GetUserId(User);
            _seminarService.RemoveSubscription(Convert.ToInt64(userId), seminarId);

            return OnGetAsync()
                .ConfigureAwait(true)
                .GetAwaiter()
                .GetResult();
        }

        private void LoadSubscriptions(long userId)
        {
            var subscriptions = _seminarService.GetSubscsriptions().ToList();

            SubscriptionsViewModels = subscriptions
                .Select(subscription => new SubscriptionViewModel(userId, subscription))
                .ToList();
        }
    }

}

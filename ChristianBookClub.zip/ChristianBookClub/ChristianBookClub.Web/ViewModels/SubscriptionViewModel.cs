﻿using ChristianBookClub.Data.Entities;

namespace ChristianBookClub.Web.ViewModels
{
	public class SubscriptionViewModel(long userId, Subscription subscription)
	{
		private readonly long _userId = userId;
		private readonly Subscription _subscription = subscription;

		public long SeminarId { get { return _subscription.SeminarId; } }
		public string Name { get { return _subscription.Name; } }
		public string Details { get { return _subscription.Details; } }
		public bool Subscribed { get { return _subscription.UserId.Equals(_userId); } }
		public DateOnly NextMeetingDate { get { return DateOnly.FromDateTime(_subscription.NextMeeting); } }
		public TimeOnly NextMeetingTime { get { return TimeOnly.FromDateTime(_subscription.NextMeeting); } }
	}
}
